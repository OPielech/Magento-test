<?php namespace Solwin\AssignOrdersToRoles\Observer;

    class OrderHistory implements Magento\Framework\Event\ObserverInterface
    {
        private static $wasClicked;

        public function execute(\Magento\Framework\Event\Observer $observer){
        $wasClicked = $observer->getData('was_clicked_text');
        
        echo $wasClicked;

	    }//end of execute
    }//end of OrderHistory