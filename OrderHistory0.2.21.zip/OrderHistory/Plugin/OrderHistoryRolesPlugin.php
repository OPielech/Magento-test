<?php namespace Solwin\OrderHistory\Plugin;

    use Magento\Framework\Message\ManagerInterface as MessageManager;
    use Solwin\OrderHistory\Model\ResourceModel\Order\Grid\Collection as OrderHistoryGridCollection;

    class OrderHistoryRolesPlugin
    {
        private $messageManager;
        private $collection;
        protected  $adminSession;
        protected $logger;

        public function __construct(MessageManager $messageManager,
            OrderHistoryGridCollection $collection,
            \Magento\Backend\Model\Auth\Session $adminSession,
            \Psr\Log\LoggerInterface $logger
        ) {

            $this->messageManager = $messageManager;
            $this->collection = $collection;
            $this->adminSession = $adminSession;
            $this->logger = $logger;
        }

        public function aroundGetReport(
            \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory $subject,
            \Closure $proceed,
            $requestName
        ) {
           $current_adminuser =   $this->adminSession->getUser()->getAclRole();
           $this->logger->addDebug("admin user");
           $this->logger->addDebug($current_adminuser);

           $result = $proceed($requestName);
           if ($requestName == 'order_history_grid_data_source') {
                if ($result instanceof $this->collection) {
                    switch ($current_adminuser) {
                        case 4:
                            $this->collection->addFieldToFilter('status', array('in' => array('accepted')));	
                            break;
                       case 6:
                           $this->collection->addFieldToFilter('status', array('in' => array('canceled')));
                            break;
                    }
                }
            }
            return $this->collection;
        }
    }