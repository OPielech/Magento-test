<?php

namespace Meetanshi\HidePrice\Plugin\Catalog\Pricing\Render;

use Meetanshi\HidePrice\Helper\Data as HelperData;
use Magento\Customer\Model\Session;
use Magento\Catalog\Pricing\Render\FinalPriceBox as CatalogFinalPriceBox;
use Magento\Catalog\Model\ProductFactory;

/**
 * Class FinalPriceBox
 * @package Meetanshi\HidePrice\Plugin\Catalog\Pricing\Render
 */
class FinalPriceBox
{
    /**
     * @var HelperData|null
     */
    protected $helper = null;
    /**
     * @var Session
     */
    protected $customerSession;
    /**
     * @var ProductFactory
     */
    protected $catalogProduct;

    /**
     * FinalPriceBox constructor.
     * @param HelperData $helper
     * @param Session $customerSession
     * @param ProductFactory $productloader
     */
    public function __construct(HelperData $helper, Session $customerSession, ProductFactory $productloader)
    {
        $this->helper = $helper;
        $this->customerSession = $customerSession;
        $this->catalogProduct = $productloader;
    }

    /**
     * @param CatalogFinalPriceBox $subject
     * @param $result
     * @return mixed|string
     */
    public function afterToHtml(CatalogFinalPriceBox $subject, $result)
    {
        if ($this->helper->isEnabled()) {
            $selectedArea = $this->helper->getHidePriceArea();
            $productData = $this->catalogProduct->create()->load($subject->getSaleableItem()->getId());
            $enableHidePrice = $productData->getData('enable_hide_price');

            if ($selectedArea == 'category') {
                if (!$this->helper->isAllowCustomerGroups()) {
                    $showInCategory = $this->helper->showPrdCategories($subject->getSaleableItem()->getId());
                    if ($showInCategory) {
                        if ($subject->getPrice()->getPriceCode() == "tier_price") {
                            return '';
                        } else {
                            return $this->helper->getHidePriceText();
                        }
                    } else {
                        return $result;
                    }
                } elseif ($this->helper->isAllowCustomerGroups()) {
                    $showInCategory = $this->helper->showPrdCategories($subject->getSaleableItem()->getId());
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($showInCategory && $customerGroupIds) {
                        if ($subject->getPrice()->getPriceCode() == "tier_price") {
                            return '';
                        } else {
                            return $this->helper->getHidePriceText();
                        }
                    } else {
                        return $result;
                    }
                }
            } elseif ($selectedArea == 'product') {
                if ($enableHidePrice && !$this->helper->isAllowCustomerGroups()) {
                    if ($subject->getSaleableItem()->getId()) {
                        if ($subject->getPrice()->getPriceCode() == "tier_price") {
                            return '';
                        } else {
                            return $this->helper->getHidePriceText();
                        }
                    } else {
                        return $result;
                    }
                } elseif ($enableHidePrice && $this->helper->isAllowCustomerGroups()) {
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($subject->getSaleableItem()->getId() && $customerGroupIds) {
                        if ($subject->getPrice()->getPriceCode() == "tier_price") {
                            return '';
                        } else {
                            return $this->helper->getHidePriceText();
                        }
                    } else {
                        return $result;
                    }
                } else {
                    return $result;
                }
            } else {
                if ($this->helper->isAllowCustomerGroups()) {
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($customerGroupIds) {
                        if ($subject->getPrice()->getPriceCode() == "tier_price") {
                            return '';
                        } else {
                            return $this->helper->getHidePriceText();
                        }
                    } else {
                        return $result;
                    }
                } else {
                    if ($subject->getPrice()->getPriceCode() == "tier_price") {
                        return '';
                    } else {
                        return $this->helper->getHidePriceText();
                    }
                }
            }
            return $result;
        } else {
            return $result;
        }
    }
}
