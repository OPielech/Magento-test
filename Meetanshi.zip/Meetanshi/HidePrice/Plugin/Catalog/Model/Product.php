<?php

namespace Meetanshi\HidePrice\Plugin\Catalog\Model;

use Meetanshi\HidePrice\Helper\Data as HelperData;
use Magento\Catalog\Model\Product as CatalogProduct;

/**
 * Class Product
 * @package Meetanshi\HidePrice\Plugin\Catalog\Model
 */
class Product
{
    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * Product constructor.
     * @param HelperData $helper
     */
    public function __construct(HelperData $helper)
    {
        $this->helper = $helper;
    }

    /**
     * @param CatalogProduct $product
     * @return $this|array
     */
    public function afterIsSaleable(CatalogProduct $product)
    {
        if ($this->helper->isEnabled()) {
            $selectedArea = $this->helper->getHidePriceArea();
            $enableHidePrice = $product->getData('enable_hide_price');

            if ($selectedArea == 'category') {
                if (!$this->helper->isAllowCustomerGroups()) {
                    $showInCategory = $this->helper->showPrdCategories($product->getId());
                    if ($showInCategory) {
                        return [];
                    } else {
                        return $this;
                    }
                } elseif ($this->helper->isAllowCustomerGroups()) {
                    $showInCategory = $this->helper->showPrdCategories($product->getId());
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($showInCategory && $customerGroupIds) {
                        return [];
                    } else {
                        return $this;
                    }
                }
            } elseif ($selectedArea == 'product') {
                if ($enableHidePrice && !$this->helper->isAllowCustomerGroups()) {
                    if ($product->getId()) {
                        return [];
                    } else {
                        return $this;
                    }
                } elseif ($enableHidePrice && $this->helper->isAllowCustomerGroups()) {
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($product->getId() && $customerGroupIds) {
                        return [];
                    } else {
                        return $this;
                    }
                } else {
                    return $this;
                }
            } else {
                if ($this->helper->isAllowCustomerGroups()) {
                    $customerGroupIds = $this->helper->showCustomerGroups();
                    if ($customerGroupIds) {
                        return [];
                    } else {
                        return $this;
                    }
                } else {
                    return [];
                }
            }
            return $this;
        } else {
            return $this;
        }
    }
}
