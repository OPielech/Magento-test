<?php

namespace Meetanshi\HidePrice\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;
use Magento\Customer\Model\ResourceModel\Group\CollectionFactory;

/**
 * Class Groups
 * @package Meetanshi\HidePrice\Model\Config\Source
 */
class Groups implements ArrayInterface
{
    /**
     * @var
     */
    protected $options;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * Groups constructor.
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(CollectionFactory $collectionFactory)
    {
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * @return array
     */
    public function toOptionArray()
    {
        if (!$this->options) {
            $this->options = $this->collectionFactory->create()->setRealGroupsFilter()->loadData()->toOptionArray();
            array_unshift($this->options, ['value' => '0', 'label' => __('NOT LOGGED IN')]);
        }

        return $this->options;
    }
}
