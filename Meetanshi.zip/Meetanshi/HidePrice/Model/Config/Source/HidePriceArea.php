<?php

namespace Meetanshi\HidePrice\Model\Config\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class HidePriceArea
 * @package Meetanshi\HidePrice\Model\Config\Source
 */
class HidePriceArea implements ArrayInterface
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'global', 'label' => __('Global')],
            ['value' => 'category', 'label' => __('Category Specific')],
            ['value' => 'product', 'label' => __('Product Specific')],
        ];
    }

    /**
     * @return array
     */
    public function toArray()
    {
        $options = $this->toOptionArray();
        $return = [];
        foreach ($options as $option) {
            $return[$option['value']] = $option['label'];
        }
        return $return;
    }
}
