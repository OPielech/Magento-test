<?php

namespace Meetanshi\HidePrice\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Catalog\Model\ProductFactory;

/**
 * Class Data
 * @package Meetanshi\HidePrice\Helper
 */
class Data extends AbstractHelper
{
    const XML_PATH_ACTIVE = 'hideprice/general/active';
    const XML_PATH_DISPLAY_TEXT = 'hideprice/general/displayed_text';
    const XML_PATH_ALLOW_CUSTOMER_GROUP = 'hideprice/general/allow_customer_group';
    const XML_PATH_DISPLAY_CUSTOMER_GROUPS = 'hideprice/general/display_customer_group';
    const XML_PATH_DISPLAY_HIDEPRICE_AREA = 'hideprice/general/allow_area';
    const XML_PATH_DISPLAY_CATEGORIES = 'hideprice/general/display_categories';
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var Session
     */
    protected $customerSession;
    /**
     * @var ProductFactory
     */
    protected $product;

    /**
     * Data constructor.
     * @param Context $context
     * @param ProductFactory $product
     * @param Session $customerSession
     * @param Registry $registry
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(Context $context, ProductFactory $product, Session $customerSession, Registry $registry, StoreManagerInterface $storeManager)
    {
        $this->registry = $registry;
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->product = $product;

        parent::__construct($context);
    }

    /**
     * @return bool
     */
    public function isCustomerLoggedIn()
    {
        $customerGroupId = $this->customerSession->getCustomerGroupId();
        if ($customerGroupId == \Magento\Customer\Model\Group::NOT_LOGGED_IN_ID) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * @return bool
     */
    public function getCurrentCategoryId()
    {
        $category = $this->registry->registry('current_category');
        if ($category != null) {
            return $this->registry->registry('current_category')->getId();
        }
        return false;
    }

    /**
     * @return bool|int
     */
    public function getLoginCustomerGroupId()
    {
        $customerGroupId = $this->customerSession->getCustomerGroupId();
        if (!empty($customerGroupId)) {
            return $customerGroupId;
        } else {
            return false;
        }
    }

    /**
     * @return mixed
     */
    public function isEnabled()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ACTIVE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getCustomerGroups()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_DISPLAY_CUSTOMER_GROUPS, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getHidePriceArea()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_DISPLAY_HIDEPRICE_AREA, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getHidePriceText()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_DISPLAY_TEXT, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return bool
     */
    public function showCategories()
    {
        $categoryIds = explode(",", $this->getCategoryIds());
        if (in_array($this->getCurrentCategoryId(), $categoryIds)) {
            return true;
        }
        return false;
    }

    /**
     * @param $productId
     * @return bool
     */
    public function showPrdCategories($productId)
    {
        $categoryIds = explode(",", $this->getCategoryIds());

        if ($this->getCurrentCategoryId()) {
            if (in_array($this->getCurrentCategoryId(), $categoryIds)) {
                return true;
            }
            return false;
        } else {
            $product = $this->product->create()->load($productId);
            $cats = $product->getCategoryIds();
            foreach ($cats as $catId) {
                if (in_array($catId, $categoryIds)) {
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * @return bool
     */
    public function showCustomerGroups()
    {
        $customerGroupIds = explode(",", $this->getCustomerGroups());
        if (in_array($this->getLoginCustomerGroupId(), $customerGroupIds)) {
            return true;
        }
        return false;
    }

    /**
     * @return mixed
     */
    public function isAllowCustomerGroups()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_ALLOW_CUSTOMER_GROUP, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getCategoryIds()
    {
        return $this->scopeConfig->getValue(self::XML_PATH_DISPLAY_CATEGORIES, ScopeInterface::SCOPE_STORE);
    }
}
