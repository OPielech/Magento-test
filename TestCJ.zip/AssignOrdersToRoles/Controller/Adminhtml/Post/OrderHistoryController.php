<?php

namespace Solwin\AssignOrdersToRoles\Controller\Adminhtml\Post;

class OrderHistoryController extends \Magento\Backend\App\Action
{
	public function execute()
	{
		$wasOrderHistoryButtonClicked = new \Magento\Framework\DataObject(array('text' => 'true'));
		$this->_eventManager->dispatch('was_order_button_history_clicked',['was_clicked_text' => $wasOrderHistoryButtonClicked]);
	
		header("Location: http://192.168.8.107/index.php/admin/sales/order/index");
		exit;
		
	}

}