<?php

namespace Solwin\AssignOrdersToRoles\Controller\Adminhtml\Post;

class OpenOrderHistory extends \Magento\Backend\App\Action
{
	public function execute()
	{
		// $wasOrderHistoryButtonClicked = new \Magento\Framework\DataObject(array('text' => 'buttonWasClicked'));
		// $this->_eventManager->dispatch('was_order_button_history_clicked',['was_clicked_text' => $wasOrderHistoryButtonClicked]);
	
		header("Location: http://192.168.8.107/index.php/admin/sales/order/index");
		exit;
		
	}

}