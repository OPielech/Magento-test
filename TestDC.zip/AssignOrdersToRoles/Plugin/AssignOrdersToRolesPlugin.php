<?php namespace Solwin\AssignOrdersToRoles\Plugin;

    use Magento\Framework\Message\ManagerInterface as MessageManager;
    use Magento\Sales\Model\ResourceModel\Order\Grid\Collection as SalesOrderGridCollection;

    class AssignOrdersToRolesPlugin
    {
        private $messageManager;
        private $collection;
        protected $adminSession;
        protected $logger;

        public function __construct(MessageManager $messageManager,
            SalesOrderGridCollection $collection,
            \Magento\Backend\Model\Auth\Session $adminSession,
            \Psr\Log\LoggerInterface $logger
        ) {

            $this->messageManager = $messageManager;
            $this->collection = $collection;
            $this->adminSession = $adminSession;
            $this->logger = $logger;
        }

        public function aroundGetReport(
            \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory $subject,
            \Closure $proceed,
            $requestName
        ) {

           if (!isset($_SESSION["wasButtonOrderHistoryClicked"])){
            $_SESSION["wasButtonOrderHistoryClicked"] = "false";
           }
           

           $current_adminuser = $this->adminSession->getUser()->getAclRole();
           $this->logger->addDebug("admin user");
           $this->logger->addDebug($current_adminuser);

           $result = $proceed($requestName);
           
           
           if ($requestName == 'sales_order_grid_data_source') {
                if ($result instanceof $this->collection) {
                    if ($_SESSION["wasButtonOrderHistoryClicked"]=="true"){
                        switch ($current_adminuser) {
                            case 4:
                                $this->collection->addFieldToFilter('status', array('in' => array('accepted')));
                                $_SESSION["wasButtonOrderHistoryClicked"] = "false";
                                break;
                            case 6:
                                $this->collection->addFieldToFilter('status', array('in' => array('canceled')));
                                $_SESSION["wasButtonOrderHistoryClicked"] = "false";
                                break;
                            }
                    }else{
                        switch ($current_adminuser) {
                            case 4:
                                $this->collection->addFieldToFilter('status', array('in' => array('pending')));	
                                break;
                            case 6:
                                $this->collection->addFieldToFilter('status', array('in' => array('pending','accepted')));
                                break;
                        }
                    }
                }
            }
            return $this->collection;
            
        }//end of aroundGetReport()
    }//end of class