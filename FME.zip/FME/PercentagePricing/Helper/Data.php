<?php


namespace FME\PercentagePricing\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    
    const XML_MODULE_ENABLE               = 'percentage_pricing/general/enabled';
    

    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct($context);
    }
    
    public function isModuleEnabled()
    {
        
        if ($this->isModuleOutputEnabled('FME_PercentagePricing') &&
                $this->scopeConfig->isSetFlag(
                    self::XML_MODULE_ENABLE,
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                )) {
            return true;
        }
    }
}
