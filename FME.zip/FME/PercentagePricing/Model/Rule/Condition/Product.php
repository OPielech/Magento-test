<?php

/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * Catalog Rule Product Condition data model
 */

namespace FME\PercentagePricing\Model\Rule\Condition;

/**
 * Class Product
 */
class Product extends \Magento\CatalogRule\Model\Rule\Condition\Product
{

}
