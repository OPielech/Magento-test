<?php

/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace FME\PercentagePricing\Model\Rule\Source;

use Magento\Framework\Data\OptionSourceInterface;

/**
 * Class IsActive
 */
class IsActive implements OptionSourceInterface
{

    /**
     * @var \FME\Geoipultimatelock\Model\Rule
     */
    protected $_percentagePricingRule;

    /**
     * Constructor
     *
     * @param \FME\Geoipultimatelock\Model\Rule $_percentagePricingRule
     */
    public function __construct(\FME\PercentagePricing\Model\Rule $_percentagePricingRule)
    {
        $this->_percentagePricingRule = $_percentagePricingRule;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $availableOptions = $this->_percentagePricingRule->getAvailableStatuses();
        $options = [];
        foreach ($availableOptions as $key => $value) {
            $options[] = [
                'label' => $value,
                'value' => $key,
            ];
        }

        return $options;
    }
}
