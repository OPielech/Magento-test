<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace FME\PercentagePricing\Model\Rule;

class CustomerGroupsOptionsProvider extends \Magento\CatalogRule\Model\Rule\CustomerGroupsOptionsProvider
{
    
    //code - nothing changed 
    
}
