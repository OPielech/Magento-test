<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace FME\PercentagePricing\Model\ResourceModel;

use \Magento\Store\Model\StoreManagerInterface;
use \Magento\Framework\Stdlib\DateTime;
use \Magento\Framework\Model\ResourceModel\Db\Context;

class Rule extends \FME\PercentagePricing\Model\ResourceModel\AbstractResource
{

    /**
     * Store model
     *
     * @var null|\Magento\Store\Model\Store
     */
    protected $_store = null;

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Stdlib\DateTime
     */
    protected $dateTime;
    
    protected $_cacheTypeList;
    
    protected $_frontCachePool;

    /**
     * Construct
     *
     * @param \Magento\Framework\Model\ResourceModel\Db\Context $context
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Stdlib\DateTime $dateTime
     * @param string $connectionName
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        DateTime $dateTime,
        \Magento\Framework\App\Cache\TypeListInterface $cacheTypeList,
        \Magento\Framework\App\Cache\Frontend\Pool $cacheFrontendPool,    
        $connectionName = null
    ) {
    
        parent::__construct($context, $connectionName);
        $this->_storeManager = $storeManager;
        $this->dateTime = $dateTime;
        $this->_cacheTypeList = $cacheTypeList;
        $this->_frontCachePool = $cacheFrontendPool;
        
    }

    protected function _construct()
    {
        $this->_init('fme_percentage_pricing', 'percentage_pricing_id');
    }

    /**
     * Set store model
     *
     * @param \Magento\Store\Model\Store $store
     * @return $this
     */
    public function setStore($store)
    {
        $this->_store = $store;
        return $this;
    }

    /**
     * Retrieve store model
     *
     * @return \Magento\Store\Model\Store
     */
    public function getStore()
    {
        return $this->_storeManager->getStore($this->_store);
    }

    /**
     * Process page data before deleting
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _beforeDelete(\Magento\Framework\Model\AbstractModel $object)
    {
        $condition = ['percentage_pricing_id = ?' => (int) $object->getId()];

        $this->getConnection()->delete($this->getTable('fme_percentage_pricing_store'), $condition);

        $this->getConnection()->delete($this->getTable('fme_percentage_pricing_customer_group'), $condition);
        
        return parent::_beforeDelete($object);
    }

    /**
     * Perform operations after object load
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _afterLoad(\Magento\Framework\Model\AbstractModel $object)
    {
        if ($object->getId()) {
            $stores = $this->lookupStoreIds($object->getId());

            $customer_groups = $this->lookupCustomerGroupIds($object->getId());
            
            $object->setData('store_id', $stores);
            
            $object->setData('customer_group_ids', $customer_groups);
        }

        return parent::_afterLoad($object);
    }

    /**
     * Assign page to store views
     *
     * @param \Magento\Framework\Model\AbstractModel $object
     * @return $this
     */
    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {
        $oldStores = $this->lookupStoreIds($object->getId());
        $newStores = (array) $object->getStores();
        if (empty($newStores)) {
            $newStores = (array) $object->getStoreId();
        }

        $stores = $object->getData("store_id");
        if (isset($stores)) :
            $table = $this->getTable('fme_percentage_pricing_store');
            $insert = array_diff($newStores, $oldStores);
            $delete = array_diff($oldStores, $newStores);

            if ($delete) {
                $where = ['percentage_pricing_id = ?' => (int) $object->getId(), 'store_id IN (?)' => $delete];

                $this->getConnection()->delete($table, $where);
            }

            if ($insert) {
                $data = [];

                foreach ($insert as $storeId) {
                    $data[] = ['percentage_pricing_id' => (int) $object->getId(), 'store_id' => (int) $storeId];
                }

                $this->getConnection()->insertMultiple($table, $data);
            }
        endif;
        
        
        $old_customer_groups = $this->lookupCustomerGroupIds($object->getId());
        $new_customer_groups = $object->getData("customer_group_ids");
        
        if (isset($new_customer_groups)) :
            $cg_table = $this->getTable('fme_percentage_pricing_customer_group');
            $insert = array_diff($new_customer_groups, $old_customer_groups);
            $delete = array_diff($old_customer_groups, $new_customer_groups);
            
            
            if ($delete) {
                $where = ['percentage_pricing_id = ?' => (int) $object->getId(), 'customer_group_id IN (?)' => $delete];

                $this->getConnection()->delete($cg_table, $where);
            }
        
            if ($insert) {
                $data = [];

                foreach ($insert as $cgId) {
                    $data[] = ['percentage_pricing_id' => (int) $object->getId(), 'customer_group_id' => (int) $cgId];
                }

                $this->getConnection()->insertMultiple($cg_table, $data);
            }
        endif;
        
        //Clean Full Page Cache
        $this->_cleanFullPageCache();
        
        return parent::_afterSave($object);
    }

    
    protected function _cleanFullPageCache() {
        
        $this->_cacheTypeList->cleanType('full_page');
        
        foreach ($this->_frontCachePool as $cacheFrontend) {
            $cacheFrontend->getBackend()->clean();
        }
        
    }
    
    /**
     * Retrieve select object for load object data
     *
     * @param string $field
     * @param mixed $value
     * @param \Magento\Cms\Model\Page $object
     * @return \Magento\Framework\DB\Select
     */
    protected function _getLoadSelect($field, $value, $object)
    {
        $select = parent::_getLoadSelect($field, $value, $object);

        if ($object->getStoreId()) {
            $storeIds = [\Magento\Store\Model\Store::DEFAULT_STORE_ID, (int) $object->getStoreId()];
            $select->join(
                ['fme_percentage_pricing_store' => $this->getTable('fme_percentage_pricing_store')],
                $this->getMainTable() . '.percentage_pricing_id = fme_percentage_pricing_store.percentage_pricing_id',
                []
            )->where(
                'is_active = ?',
                1
            )->where(
                'fme_percentage_pricing_store.store_id IN (?)',
                $storeIds
            )->order(
                'fme_percentage_pricing_store.store_id DESC'
            )->limit(
                1
            );
        }

        return $select;
    }

    /**
     * Get store ids to which specified item is assigned
     *
     * @param int $Id
     * @return array
     */
    public function lookupStoreIds($Id)
    {
        $connection = $this->getConnection();

        $select = $connection->select()
            ->from($this->getTable('fme_percentage_pricing_store'), 'store_id')
            ->where('percentage_pricing_id = ?', (int) $Id);

        return $connection->fetchCol($select);
    }
    
    public function lookupCustomerGroupIds($Id)
    {
        $connection = $this->getConnection();

        $select = $connection->select()
            ->from($this->getTable('fme_percentage_pricing_customer_group'), 'customer_group_id')
            ->where('percentage_pricing_id = ?', (int) $Id);

        return $connection->fetchCol($select);
    }
}
