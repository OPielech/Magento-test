<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace FME\PercentagePricing\Model\ResourceModel\Rule;

//use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends \Magento\Rule\Model\ResourceModel\Rule\Collection\AbstractCollection
{

    /**
     * @var string
     */
    protected $_idFieldName = 'percentage_pricing_id';

    /**
     * Store manager
     *
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
    
    protected $serializer;
    
    

    /**
     * @param \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy
     * @param \Magento\Framework\Event\ManagerInterface $eventManager
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param mixed $connection
     * @param \Magento\Framework\Model\Resource\Db\AbstractDb $resource
     */
    public function __construct(
        \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
        \Magento\Framework\Event\ManagerInterface $eventManager,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        $connection = null,
        \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null,
        \Magento\Framework\Serialize\SerializerInterface $serializer = null    
    ) {
         
        parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
        $this->_storeManager = $storeManager;
        $this->serializer = $serializer;
        
    }

    protected function _construct()
    {
        $this->_init(
            'FME\PercentagePricing\Model\Rule',
            'FME\PercentagePricing\Model\ResourceModel\Rule'
        );
    }

    /**
     * Find product attribute in conditions or actions
     *
     * @param string $attributeCode
     * @return $this
     * @api
     */
    public function addAttributeInConditionFilter($attributeCode)
    {
        $match = sprintf('%%%s%%', substr($this->serializer->serialize(['attribute' => $attributeCode]), 5, -1));
        $this->addFieldToFilter('conditions_serialized', ['like' => $match]);

        return $this;
    }

    public function addStoreFilter($store, $withAdmin = true)
    {
     
        if ($store instanceof \Magento\Store\Model\Store) {
            $store = [$store->getId()];
        }

        $this->getSelect()
                ->join(
                    ['store_table' => $this->getTable('fme_percentage_pricing_store')],
                    'main_table.percentage_pricing_id = store_table.percentage_pricing_id',
                    []
                )
                ->where('store_table.store_id in (?)', [0, $store])
                ->group('main_table.percentage_pricing_id');
                
        return $this;
    }
    
    
    public function addCustomerGroupFilter($group_id, $withAdmin = true)
    {
     
        //if ($group_id) {
         
            $this->getSelect()
                    ->join(
                        ['group_table' => $this->getTable('fme_percentage_pricing_customer_group')],
                        'main_table.percentage_pricing_id = group_table.percentage_pricing_id',
                        []
                    )
                    ->where('group_table.customer_group_id = (?)', $group_id);                    
        //}
        
        return $this;
    }
    

    public function addFieldToFilter($field, $condition = null)
    {
        if ($field === 'store_id') {
            return $this->addStoreFilter($condition, false);
        }

        return parent::addFieldToFilter($field, $condition);
    }

    /**
     * Perform operations after collection load
     *
     * @return $this
     */
    protected function _afterLoad()
    {
        $items = $this->getColumnValues('percentage_pricing_id');
        if (count($items)) {
            $connection = $this->getConnection();
            $select = $connection->select()->from(['cps' => $this->getTable('fme_percentage_pricing_store')])
                    ->where('cps.percentage_pricing_id IN (?)', $items);
            $result = $connection->fetchPairs($select);
            if ($result) {
                foreach ($this as $item) {
                    $pageId = $item->getData('percentage_pricing_id');
                    if (!isset($result[$pageId])) {
                        continue;
                    }

                    if ($result[$pageId] == 0) {
                        $stores = $this->_storeManager->getStores(false, true);
                        $storeId = current($stores)->getId();
                        $storeCode = key($stores);
                    } else {
                        $storeId = $result[$item->getData('percentage_pricing_id')];
                        $storeCode = $this->_storeManager->getStore($storeId)->getCode();
                    }

                    $item->setData('_first_store_id', $storeId);
                    $item->setData('store_code', $storeCode);
                    $item->setData('store_id', [$result[$pageId]]);
                }
            }
        }

        $this->_previewFlag = false;
        return parent::_afterLoad();
    }

    /**
     * Join store relation table if there is store filter
     *
     * @return void
     */
    protected function _renderFiltersBefore()
    {
        if ($this->getFilter('store')) {
            $this->getSelect()->join(
                ['store_table' => $this->getTable('fme_percentage_pricing_store')],
                'main_table.percentage_pricing_id = store_table.percentage_pricing_id',
                []
            )->group(
                'main_table.percentage_pricing_id'
            );
        }

        parent::_renderFiltersBefore();
    }

    /**
     * Add collection filters by identifiers
     *
     * @param mixed $ruleId
     * @param boolean $exclude
     * @return $this
     */
    public function addIdFilter($ruleId, $exclude = false)
    {
//        if (empty($ruleId)) {
//            $this->_setIsLoaded(true);
//            return $this;
//        }
        if (is_array($ruleId)) {
            if (!empty($ruleId)) {
                if ($exclude) {
                    $condition = ['nin' => $ruleId];
                } else {
                    $condition = ['in' => $ruleId];
                }
            } else {
                $condition = '';
            }
        } else {
            if ($exclude) {
                $condition = ['neq' => $ruleId];
            } else {
                $condition = $ruleId;
            }
        }
        
        $this->addFieldToFilter('main_table.percentage_pricing_id', $condition);
        return $this;
    }

    
    public function addStatusFilter($isActive = true)
    {

        $this->getSelect()
                ->where('main_table.is_active = ? ', $isActive);

        return $this;
    }

    public function addPriorityFilter($dir = 'ASC')
    {

        $this->getSelect()
                ->order('main_table.sort_order ' . $dir);

        return $this;
    }

    public function addLimit($limit = 1)
    {

        $this->getSelect()
                ->limit($limit);

        return $this;
    }

    
}
