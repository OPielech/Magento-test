<?php

namespace FME\PercentagePricing\Model\ResourceModel;

abstract class AbstractResource extends \Magento\Rule\Model\ResourceModel\AbstractResource
{

    /**
     * Retrieve website ids of specified rule
     *
     * @param int $ruleId
     * @return array
     */
    public function getStoreIds($ruleId)
    {
        return $this->getAssociatedEntityIds($ruleId, 'store');
    }
}
