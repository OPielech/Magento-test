<?php

namespace FME\PercentagePricing\Controller\Adminhtml\Rule;

use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;

class Save extends \Magento\Backend\App\Action
{

    protected $dataPersistor;
    
    
    public function __construct(
        Context $context,
        DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        parent::__construct($context);
    }
    
    
    
    
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('FME_PercentagePricing::rule');
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();

        //echo "<pre>"; print_r($data);
        
        
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            try {
                $model = $this->_objectManager->create(\FME\PercentagePricing\Model\Rule::class);



                $id = $this->getRequest()->getParam('percentage_pricing_id');

                if ($id) {
                    $model->load($id);
                }

                if (isset($data['rule'])) {
                    $data['conditions'] = $data['rule']['conditions'];
                    unset($data['rule']);
                }

                //only for UI base form for new record to add
                if ($data['percentage_pricing_id'] == '') {
                    unset($data['percentage_pricing_id']);
                }


                $model->loadPost($data);

                $this->_objectManager->get('Magento\Backend\Model\Session')->setPageData($model->getData());
                $this->dataPersistor->set('percentage_pricing_rule', $data);


                $model->save();





                    $this->messageManager->addSuccess(__('Rule saved successfully.'));
                    //$this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                    $this->_objectManager->get(\Magento\Backend\Model\Session::class)->setPageData(false);
                    $this->dataPersistor->clear('percentage_pricing_rule');


                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }

                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the rule.').$e->getMessage());
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('percentage_pricing_id')]);
        }

        return $resultRedirect->setPath('*/*/');
    }
}
