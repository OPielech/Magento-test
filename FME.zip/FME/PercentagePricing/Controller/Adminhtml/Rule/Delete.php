<?php

namespace FME\PercentagePricing\Controller\Adminhtml\Rule;

use Magento\Backend\App\Action;

class Delete extends \Magento\Backend\App\Action
{
    
    protected $_geoipDefaultStoreFactory;
    
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
        \FME\PercentagePricing\Model\RuleFactory $rule
    ) {
    
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        $this->_geoipDefaultStoreFactory = $rule;
        parent::__construct($context);
    }
    
    /**
     * @return void
     */
    public function execute()
    {
        $Id = (int) $this->getRequest()->getParam('id');

        if ($Id) {
            $model = $this->_geoipDefaultStoreFactory->create();
            $model->load($Id);

            
            if (!$model->getId()) {
                $this->messageManager->addError(__('Rule no longer exists.'));
            } else {
                try {
                    $model->delete();
                    $this->messageManager->addSuccess(__('Rule has been deleted.'));

            
                    $this->_redirect('*/*/');
                    return;
                } catch (\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                    $this->_redirect('*/*/edit', ['id' => $model->getId()]);
                }
            }
        }
    }
}
