<?php

/*
 * This file will declare and create your custom table
 */

namespace FME\PercentagePricing\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{

    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        // Get v table
        $tableName = $installer->getTable('fme_percentage_pricing');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableName) != true) {
            $table = $installer->getConnection()
                    ->newTable($tableName)
                    ->addColumn(
                        'percentage_pricing_id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'name',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        255,
                        [],
                        'Name'
                    )
                    ->addColumn(
                        'description',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        '64k',
                        [],
                        'Description'
                    )
                    ->addColumn(
                        'from_date',
                        \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                        null,
                        [],
                        'From'
                    )
                    ->addColumn(
                        'to_date',
                        \Magento\Framework\DB\Ddl\Table::TYPE_DATE,
                        null,
                        [],
                        'To'
                    )
                    ->addColumn(
                        'is_active',
                        \Magento\Framework\DB\Ddl\Table::TYPE_SMALLINT,
                        null,
                        ['nullable' => false, 'default' => '0'],
                        'Is Active'
                    )
                    ->addColumn(
                        'conditions_serialized',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        '2M',
                        [],
                        'Conditions Serialized'
                    )
                    ->addColumn(
                        'actions_serialized',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        '2M',
                        [],
                        'Actions Serialized'
                    )
                    ->addColumn(
                        'action_add_sub',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        32,
                        [],
                        'Add Subtract Action'
                    )
                    ->addColumn(
                        'sort_order',
                        \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                        null,
                        ['unsigned' => true, 'nullable' => false, 'default' => '0'],
                        'Sort Order'
                    )
                    ->addColumn(
                        'simple_action',
                        \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        32,
                        [],
                        'Simple Action Percent or Fixed'
                    )
                    ->addColumn(
                        'discount_amount',
                        \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        [12, 4],
                        ['nullable' => false, 'default' => 0.0000],
                        'Discount Amount'
                    )
                    ->setComment('main Table')
                    ->setOption('type', 'InnoDB')
                    ->setOption('charset', 'utf8');
            $installer->getConnection()->createTable($table);
        }

        

        $tableStore = $installer->getTable('fme_percentage_pricing_store');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableStore) != true) {
            $table = $installer->getConnection()
                    ->newTable($tableStore)
                    ->addColumn(
                        'percentage_pricing_id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                        'identity' => true,
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'store_id',
                        Table::TYPE_SMALLINT,
                        null,
                        [
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                        ],
                        'Store ID'
                    )
                    ->addIndex(
                        $installer->getIdxName('fme_percentage_pricing_store', ['store_id']),
                        ['store_id']
                    )->addForeignKey(
                        $installer->getFkName(
                            'fme_percentage_pricing_store',
                            'percentage_pricing_id',
                            'fme_percentage_pricing',
                            'percentage_pricing_id'
                        ),
                        'percentage_pricing_id',
                        $installer->getTable('fme_percentage_pricing'),
                        'percentage_pricing_id',
                        \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                    )->addForeignKey(
                        $installer->getFkName(
                            'fme_percentage_pricing_store',
                            'store_id',
                            'store',
                            'store_id'
                        ),
                        'store_id',
                        $installer->getTable('store'),
                        'store_id',
                        \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                    )->setComment(
                        'FME percentage pricing To Store Linkage Table'
                    );

            $installer->getConnection()->createTable($table);
        }

        
        
        $tableGroup = $installer->getTable('fme_percentage_pricing_customer_group');
        // Check if the table already exists
        if ($installer->getConnection()->isTableExists($tableGroup) != true) {
            $table = $installer->getConnection()
                    ->newTable($tableGroup)
                    ->addColumn(
                        'percentage_pricing_id',
                        Table::TYPE_INTEGER,
                        null,
                        [
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                        ],
                        'ID'
                    )
                    ->addColumn(
                        'customer_group_id',
                        Table::TYPE_SMALLINT,
                        null,
                        [
                        'unsigned' => true,
                        'nullable' => false,
                        'primary' => true
                        ],
                        'Customer Group ID'
                    )
                    ->addIndex(
                        $installer->getIdxName('fme_percentage_pricing_customer_group', ['customer_group_id']),
                        ['customer_group_id']
                    )->addForeignKey(
                        $installer->getFkName(
                            'fme_percentage_pricing_customer_group',
                            'percentage_pricing_id',
                            'fme_percentage_pricing',
                            'percentage_pricing_id'
                        ),
                        'percentage_pricing_id',
                        $installer->getTable('fme_percentage_pricing'),
                        'percentage_pricing_id',
                        \Magento\Framework\DB\Ddl\Table::ACTION_CASCADE
                    );

            $installer->getConnection()->createTable($table);
        }
        
        $installer->endSetup();
    }
}
