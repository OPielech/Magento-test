<?php

/**
 * (V1.0.2)
 */

namespace FME\PercentagePricing\Observer;

class UpdatePriceCart implements \Magento\Framework\Event\ObserverInterface
{
    
    protected $_request;
    
    protected $_helper;
    
    protected $_ruleFactory;
    
    protected $_dateTime;
    
    protected $_storeManager;
    
    protected $httpContext;
    
    
    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \FME\PercentagePricing\Helper\Data $helper,
        \FME\PercentagePricing\Model\RuleFactory $ruleFactory,    
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\App\Http\Context $httpContext    
    ) {

        $this->_request = $request;
        $this->_helper = $helper; 
        $this->_ruleFactory = $ruleFactory;
        $this->_dateTime = $dateTime;
        $this->_storeManager = $storeManager;
        $this->httpContext = $httpContext;
    }
    

    public function execute(\Magento\Framework\Event\Observer $observer)
    {

        if (!$this->_helper->isModuleEnabled()) :
            return;
        endif;
        
        $quoteItem = $observer->getEvent()->getQuoteItem();
        $_product = $observer->getProduct();
        
        
        $product_cost = $_product->getCost();
        
        
        //NOTE : check cost attribute, visible for catelog front listing & view
        
        //NOTE : Configurable product (parent) dont have Cost set, so (V1.0.2)
        if($_product->getTypeId() != 'configurable'){
        
            if ($product_cost <= 0 || $product_cost == '') {
                return;
            }
        }
        
        if ($_product) :
            //check the rules where this product lies
            
            $now = $this->_dateTime->gmtDate('Y-m-d');
        
            $customerGroup = $this->httpContext->getValue('customer_group_id');
            
            $ruleFactory = $this->_ruleFactory->create();
            $rules = $ruleFactory->getCollection()
                                    ->addStatusFilter(1)
                                    ->addPriorityFilter('ASC')
                                    ->addFieldToFilter('main_table.from_date', [['lteq' => $now], ['null' => true]])
                                    ->addFieldToFilter('main_table.to_date', [['gteq' => $now], ['null' => true]])
                                    ->addCustomerGroupFilter($customerGroup)
                                    ->addStoreFilter([$this->_storeManager->getStore()->getId()], false); //website needed not stores
            
                      
            if ($rules->count() < 1) {
                return;
            }
            
            $ruleProducts = [];
            
            foreach ($rules as $item) {
                $rule = $this->_ruleFactory->create()
                        ->load($item->getId());
                
                if ($rule->getConditions()->validate($_product)) {
                    $ruleProducts[$item->getId()] = $_product->getId();
                }
            }
            
            $allRules = array_keys($ruleProducts);

            
            
            if (empty($allRules)) {
                return;
            } else {
                $rules->addIdFilter($allRules)
                        ->addPriorityFilter()
                        ->addLimit(); //limit is 1 by default
            }
            
            
            if ($rules_data = $rules->getData()) {
                $final_rule = $rules_data[0];
                
                $ruleObj = $this->_ruleFactory->create()->load($final_rule['percentage_pricing_id']);
                
                               
                //NOTE : check cost attribute, visible for catelog front listing & view
                ////for configurable parent item. condition was never true. (V1.0.2)
                //if ($product_cost > 0 && $product_cost != '') {
                    
                    //percentage price already set on catalog-page. get and set as custom-price
                    $final_price = $quoteItem->getProduct()->getFinalPrice(); //base-price + selected options
                    
                    $item = ( $quoteItem->getParentItem() ? $quoteItem->getParentItem() : $quoteItem );
                    $item->setCustomPrice($final_price);
                    $item->setOriginalCustomPrice($final_price);
                    $item->getProduct()->setIsSuperMode(true);
                //}
            }
            
            
        endif;
        
        return;
        
        
    }
    
    
}
