<?php

namespace Solwin\AssignOrdersToRoles\Controller\Adminhtml\Post;

class OrderHistoryController extends \Magento\Backend\App\Action
{
	public function execute()
	{
        $_SESSION["wasButtonOrderHistoryClicked"] = "true";

		header("Location: http://192.168.8.107/index.php/admin/sales/order/index");
		exit;
		
	}

}