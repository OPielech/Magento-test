<?php namespace Solwin\AssignOrdersToRoles\Plugin;

    use Magento\Framework\Message\ManagerInterface as MessageManager;
    use Magento\Sales\Model\ResourceModel\Order\Grid\Collection as SalesOrderGridCollection;
    use Solwin\OrderHistory\Model\ResourceModel\Order\Grid\Collection as OrderHistoryGridCollection;

    class AssignOrdersToRolesPlugin
    {
        private $messageManager;
        private $collection;
        private $orderHistoryCollection;
        protected  $adminSession;
        protected $logger;

        public function __construct(
            MessageManager $messageManager,
            SalesOrderGridCollection $collection,
            OrderHistoryGridCollection $orderHistoryCollection,
            \Magento\Backend\Model\Auth\Session $adminSession,
            \Psr\Log\LoggerInterface $logger
        ) {

            $this->messageManager = $messageManager;
            $this->collection = $collection;
            $this->orderHistoryCollection = $orderHistoryCollection;
            $this->adminSession = $adminSession;
            $this->logger = $logger;
        }

        public function aroundGetReport(
            \Magento\Framework\View\Element\UiComponent\DataProvider\CollectionFactory $subject,
            callable $proceed,
            $requestName
        ) {
           $current_adminuser =   $this->adminSession->getUser()->getAclRole();
           $this->logger->addDebug("admin user");
           $this->logger->addDebug($current_adminuser);

    
            if ($requestName == 'sales_order_grid_data_source') {
                
                switch ($current_adminuser) {
                        case 20:
                            $this->collection->addFieldToFilter('status', array('in' => array('pending')));
                            $this->collection->addFieldToFilter('customer_group', array('in' => array(11)));
                            break;
                        case 21:
                            $this->collection->addFieldToFilter('status', array('in' => array('pending')));
                            $this->collection->addFieldToFilter('customer_group', array('in' => array(12)));	
                            break;
                        case 6:
                            $this->collection->addFieldToFilter('status', array('in' => array('pending','accepted')));
                            break;
                }
                    return $this->collection;

               }else if ($requestName == 'order_history_grid_data_source'){

                    switch ($current_adminuser) {
                        case 20:
                            $this->orderHistoryCollection->addFieldToFilter('status', array('in' => array('accepted')));
                            $this->orderHistoryCollection->addFieldToFilter('customer_group', array('in' => array(11)));	
                            break;
                        case 21:
                            $this->orderHistoryCollection->addFieldToFilter('status', array('in' => array('accepted')));
                            $this->orderHistoryCollection->addFieldToFilter('customer_group', array('in' => array(12)));
                            break;
                        case 6:
                            $this->orderHistoryCollection->addFieldToFilter('status', array('in' => array('canceled')));
                            break;
                    }
                    return $this->orderHistoryCollection;

                }else{

                    $defaultCollection = $proceed($requestName);
                    return $defaultCollection;
                }
        }//end of beforeGetReport()
    }//end of class
    