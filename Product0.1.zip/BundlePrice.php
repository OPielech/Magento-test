<?php

namespace FME\PercentagePricing\Plugin\Product;

class BundlePrice 
{
    
    protected $productRepository;
    
    protected $_ruleFactory;
    
    protected $_storeManager;
    
    protected $_dateTime;

    protected $_customerSession;
    
    protected $_helper;
    
    protected $_objectManager;
    
    protected $httpContext;
 
    public function __construct(
        
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
        \FME\PercentagePricing\Model\RuleFactory $ruleFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Stdlib\DateTime\DateTime $dateTime,
        //\Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\ObjectManagerInterface $objectmanager,    
        \FME\PercentagePricing\Helper\Data  $helper,
        \Magento\Framework\App\Http\Context $httpContext    
    ) {
        
       $this->productRepository = $productRepository;
       $this->_ruleFactory = $ruleFactory;
       $this->_storeManager = $storeManager;
       $this->_dateTime = $dateTime;
       //$this->_customerSession = $customerSession;
       $this->_helper = $helper;
       $this->_objectManager = $objectmanager;
       $this->httpContext = $httpContext;
       
    }
    

    public function afterGetValue(\Magento\Bundle\Pricing\Price\BundleSelectionPrice $subject, $result_price)
    {
        
        
        if(!$this->_helper->isModuleEnabled()):
            return $result_price;           
        endif;
        
        $product = $subject->getProduct();
        
        $_product = $this->productRepository->getById($product->getId());
        
        if($_product):
            
            //check the rules where this product lies
            
            $now = $this->_dateTime->gmtDate('Y-m-d');
        
            $customerGroup = $this->httpContext->getValue('customer_group_id');
                    
            $ruleFactory = $this->_ruleFactory->create();
            $rules = $ruleFactory->getCollection()
                                    ->addStatusFilter(1)
                                    ->addPriorityFilter('ASC')
                                    ->addFieldToFilter('main_table.from_date', [['lteq' => $now], ['null' => true]])
                                    ->addFieldToFilter('main_table.to_date', [['gteq' => $now], ['null' => true]])
                                    ->addCustomerGroupFilter($customerGroup)
                                    ->addStoreFilter([$this->_storeManager->getStore()->getId()], false); //website needed not stores
            
            if ($rules->count() < 1) {
                return $result_price; // proceed with orignal results
            }
            
            $ruleProducts = [];
            
            foreach ($rules as $item) {
                
                $rule = $this->_ruleFactory->create()
                        ->load($item->getId());
 
                if ($rule->getConditions()->validate($_product)) {
                    $ruleProducts[$item->getId()] = $_product->getId();
                }
            }
            
            $allRules = array_keys($ruleProducts);

            
            
            if (empty($allRules)) {
                return $result_price; // proceed with orignal results
            } else {
                $rules->addIdFilter($allRules)
                        ->addPriorityFilter()
                        ->addLimit(); //limit is 1 by default
            }
            
            if($rules_data = $rules->getData()){
                
                $final_rule = $rules_data[0];
                
                $ruleObj = $this->_ruleFactory->create()->load($final_rule['percentage_pricing_id']);

                    $new_price = $this->getProductRulePrice($ruleObj, $result_price);
                                      
                    
                    if($new_price > 0):
                        
                        return $new_price;
                    
                    endif;                    
                           
                
            }
            
            
        endif;
        
        
        return $result_price;
    }
    
    
    
    public function getProductRulePrice($rule, $result_price){
        
        
        //apply rule actions to product cost
                    
        $simple_action = $rule->getSimpleAction(); //by_percent, by_fixed
        $action_add_sub = $rule->getActionAddSub(); // add, subtract 
        $amount = $rule->getDiscountAmount();
                    
        $total_amount = 0;
                    
        if($simple_action == 'by_fixed'):
                        
            if($action_add_sub == 'add'):
                $total_amount = $result_price + $amount;                        
            elseif($action_add_sub == 'subtract'):
                $total_amount = ($amount <= $result_price) ? ($result_price - $amount) : 0;
            endif;
                        
        elseif($simple_action == 'by_percent'):    
                        
            $percent_amount =  $result_price * ($amount/100);
        
            if($action_add_sub == 'add'):
                $total_amount = $result_price + $percent_amount;                        
            elseif($action_add_sub == 'subtract'):
                $total_amount = ($percent_amount <= $result_price) ? ($result_price - $percent_amount) : 0;
            endif;
            
        endif;
        
        return $total_amount;
        
    }
}
