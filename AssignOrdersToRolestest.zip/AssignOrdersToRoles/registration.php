<?php
/**
 * Copyright © 2019 Magento. All rights reserved.
 * Custom plugin created by Oskar Pielech
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Oskar_Pielech_AssignOrdersToRoles',
    __DIR__
);
